import java.io.FileInputStream
import java.util.Properties
import com.google.gms.googleservices.GoogleServicesPlugin.MissingGoogleServicesStrategy

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.secrets)
  alias(libs.plugins.google.services)
}

// --- Central Multi-App Version Resolution ---
val versionPropsFile = rootProject.file("version.properties")
val versionProps = Properties().apply {
  if (versionPropsFile.exists()) {
    FileInputStream(versionPropsFile).use { load(it) }
  }
}

val vMajor = (versionProps.getProperty("VERSION_MAJOR") ?: "1").toIntOrNull() ?: 1
val vMinor = (versionProps.getProperty("VERSION_MINOR") ?: "0").toIntOrNull() ?: 0
val vPatch = (versionProps.getProperty("VERSION_PATCH") ?: "0").toIntOrNull() ?: 0
val vBuild = (versionProps.getProperty("VERSION_BUILD") ?: "1").toIntOrNull() ?: 1
val vQualifier = versionProps.getProperty("VERSION_QUALIFIER", "").trim()

val computedVersionCode = vMajor * 10000 + vMinor * 100 + vPatch * 10 + vBuild
val computedVersionName = if (vQualifier.isNotEmpty()) "$vMajor.$vMinor.$vPatch-$vQualifier" else "$vMajor.$vMinor.$vPatch"

val dynamicVersionCode = (project.findProperty("versionCode") as? String)?.toIntOrNull() ?: computedVersionCode
val dynamicVersionName = (project.findProperty("versionName") as? String) ?: computedVersionName

// --- Multi-App Category & Tier Architecture for Mass Deployment (662+ Apps) ---
val isFlavorsEnabled = (project.findProperty("enableFlavors") as? String)?.toBoolean() ?: false

val activeCategory = (project.findProperty("category") as? String)?.lowercase() ?: "state"
val activeTier = (project.findProperty("tier") as? String)?.lowercase() ?: "pro"

data class CategoryMeta(val id: String, val name: String, val packageSuffix: String, val primaryColorHex: String)
val categories = mapOf(
  "state" to CategoryMeta("STATE_PSC", "State Public Service Exams", "state", "0xFF0284C7"),
  "railways" to CategoryMeta("RAILWAYS", "Central Railways Recruitment", "railways", "0xFF16A34A"),
  "banking" to CategoryMeta("BANKING", "Banking & Financial Services", "banking", "0xFF7C3AED"),
  "ssc" to CategoryMeta("SSC", "Staff Selection Commission Exams", "ssc", "0xFFEA580C"),
  "teaching" to CategoryMeta("TEACHING", "Teachers Eligibility & Recruitment", "teaching", "0xFF059669"),
  "defense" to CategoryMeta("DEFENSE", "Defense & Armed Forces Services", "defense", "0xFFB45309"),
  "civil" to CategoryMeta("CIVIL_SERVICES", "Union & State Civil Services", "civil", "0xFF1E293B")
)

data class TierMeta(val id: String, val label: String, val aiMentor: Boolean, val offlineVault: Boolean, val unlimitedMocks: Boolean)
val tiers = mapOf(
  "standard" to TierMeta("STANDARD", "Standard Edition", false, true, false),
  "pro" to TierMeta("PRO", "Professional Pro Edition", true, true, true),
  "enterprise" to TierMeta("ENTERPRISE", "Institutional Enterprise Edition", true, true, true)
)

val currentCategoryMeta = categories[activeCategory] ?: categories["state"]!!
val currentTierMeta = tiers[activeTier] ?: tiers["pro"]!!

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    val targetAppId = (project.findProperty("appId") as? String) ?: "andhra-pradesh-appsc-group-2"
    val targetTenantId = (project.findProperty("tenantId") as? String) ?: "APP001"
    val defaultPackage = "com.aistudio.appscprep.fhdqkx"
    applicationId = (project.findProperty("appPackage") as? String) ?: defaultPackage
    minSdk = 24
    targetSdk = 36
    versionCode = dynamicVersionCode
    versionName = dynamicVersionName

    buildConfigField("String", "APP_ID", "\"$targetAppId\"")
    buildConfigField("String", "TENANT_ID", "\"$targetTenantId\"")
    buildConfigField("int", "APP_VERSION_CODE", "$dynamicVersionCode")
    buildConfigField("String", "APP_VERSION_NAME", "\"$dynamicVersionName\"")

    // Category & Tier configuration fields for dynamic multi-tenant runtime
    buildConfigField("String", "APP_CATEGORY", "\"${currentCategoryMeta.id}\"")
    buildConfigField("String", "APP_CATEGORY_NAME", "\"${currentCategoryMeta.name}\"")
    buildConfigField("String", "APP_TIER", "\"${currentTierMeta.id}\"")
    buildConfigField("boolean", "FEATURE_AI_MENTOR_ENABLED", "${currentTierMeta.aiMentor}")
    buildConfigField("boolean", "FEATURE_OFFLINE_VAULT_ENABLED", "${currentTierMeta.offlineVault}")
    buildConfigField("boolean", "FEATURE_UNLIMITED_MOCKS_ENABLED", "${currentTierMeta.unlimitedMocks}")

    // Resource Configurations for dynamic category & tier branding
    resValue("string", "app_category_id", currentCategoryMeta.id)
    resValue("string", "app_category_name", currentCategoryMeta.name)
    resValue("string", "app_tier_label", currentTierMeta.label)

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  // Mass Deployment Product Flavors:
  // Activated during CI/CD mass-build matrix via -PenableFlavors=true
  if (isFlavorsEnabled) {
    flavorDimensions += listOf("category", "tier")
    productFlavors {
      create("stateExams") {
        dimension = "category"
        applicationIdSuffix = ".state"
        resValue("string", "flavor_category", "State PSC & Police")
        buildConfigField("String", "FLAVOR_CATEGORY", "\"STATE_PSC\"")
      }
      create("centralRailways") {
        dimension = "category"
        applicationIdSuffix = ".railways"
        resValue("string", "flavor_category", "Central Railways")
        buildConfigField("String", "FLAVOR_CATEGORY", "\"RAILWAYS\"")
      }
      create("banking") {
        dimension = "category"
        applicationIdSuffix = ".banking"
        resValue("string", "flavor_category", "Banking & Finance")
        buildConfigField("String", "FLAVOR_CATEGORY", "\"BANKING\"")
      }
      create("ssc") {
        dimension = "category"
        applicationIdSuffix = ".ssc"
        resValue("string", "flavor_category", "Staff Selection Commission")
        buildConfigField("String", "FLAVOR_CATEGORY", "\"SSC\"")
      }
      create("teaching") {
        dimension = "category"
        applicationIdSuffix = ".teaching"
        resValue("string", "flavor_category", "Teaching & TET")
        buildConfigField("String", "FLAVOR_CATEGORY", "\"TEACHING\"")
      }
      create("defense") {
        dimension = "category"
        applicationIdSuffix = ".defense"
        resValue("string", "flavor_category", "Defense Services")
        buildConfigField("String", "FLAVOR_CATEGORY", "\"DEFENSE\"")
      }
      create("civilServices") {
        dimension = "category"
        applicationIdSuffix = ".civil"
        resValue("string", "flavor_category", "Civil Services")
        buildConfigField("String", "FLAVOR_CATEGORY", "\"CIVIL_SERVICES\"")
      }

      create("standard") {
        dimension = "tier"
        buildConfigField("String", "FLAVOR_TIER", "\"STANDARD\"")
      }
      create("pro") {
        dimension = "tier"
        applicationIdSuffix = ".pro"
        buildConfigField("String", "FLAVOR_TIER", "\"PRO\"")
      }
    }
  }

  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
    create("debugConfig") {
      storeFile = file("${rootDir}/debug.keystore")
      storePassword = "android"
      keyAlias = "androiddebugkey"
      keyPassword = "android"
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName("release")
    }
    debug { signingConfig = signingConfigs.getByName("debugConfig") }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
    resValues = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

// Configure the Secrets Gradle Plugin to use .env and .env.example files
// to match the convention used in Web projects.
secrets {
  propertiesFileName = ".env"
  defaultPropertiesFileName = ".env.example"
  ignoreList.add("FIREBASE_APPCHECK_DEBUG_TOKEN")
}

googleServices { missingGoogleServicesStrategy = MissingGoogleServicesStrategy.WARN }

// Some unused dependencies are commented out below instead of being removed.
// This makes it easy to add them back in the future if needed.
dependencies {
  implementation(libs.gson)
  implementation(platform(libs.androidx.compose.bom))
  implementation(platform(libs.firebase.bom))
  // implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  // implementation(libs.androidx.camera.camera2)
  // implementation(libs.androidx.camera.core)
  // implementation(libs.androidx.camera.lifecycle)
  // implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.material3.windowsizeclass)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.core.splashscreen)
  implementation(libs.androidx.work.runtime.ktx)
  implementation(libs.play.billing.ktx)
  implementation(libs.razorpay.checkout) {
    exclude(group = "com.razorpay", module = "core")
  }
  implementation(libs.exp4j)
  // implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  implementation(libs.androidx.navigation.compose)
  implementation(libs.androidx.room.ktx)
  implementation(libs.androidx.room.runtime)
  implementation(libs.coil.compose)
  implementation(libs.converter.moshi)
  implementation(libs.firebase.ai)
  implementation(libs.firebase.firestore)
  implementation(libs.firebase.auth)
  implementation(libs.firebase.storage)
  implementation(libs.firebase.messaging)
  implementation(libs.firebase.analytics)

  // Dependencies for Firebase Auth and Google Sign-In via Credential Manager:
  implementation(libs.androidx.credentials)
  implementation(libs.androidx.credentials.play.services)
  implementation(libs.googleid)
  implementation(libs.vico.compose)
  implementation(libs.vico.compose.m3)
  implementation(libs.vico.core)
  implementation(libs.firebase.appcheck.recaptcha)
  implementation(libs.firebase.appcheck.debug)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  implementation(libs.kotlinx.coroutines.play.services)
  implementation(libs.logging.interceptor)
  implementation(libs.moshi.kotlin)
  implementation(libs.okhttp)
  // implementation(libs.play.services.location)
  implementation(libs.retrofit)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  "ksp"(libs.androidx.room.compiler)
  "ksp"(libs.moshi.kotlin.codegen)
}
