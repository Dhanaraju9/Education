# Razorpay SDK ProGuard Rules
-keepattributes *Annotation*
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.razorpay.** {*;}
-dontwarn com.razorpay.**
-keep class com.google.android.gms.internal.** {*;}
-dontwarn com.google.android.gms.internal.**

# Keep models for Moshi & Room
-keepclassmembers class * {
    @com.squareup.moshi.* <fields>;
}

# -----------------------------------------------------------------------------------------
# Production Optimization & Obfuscation Rules for Play Store
# -----------------------------------------------------------------------------------------

# Standard attributes preservation (crucial for stack traces, annotations, and generic signatures)
-keepattributes Signature,ElementValuePairs,AnnotationDefault,EnclosingMethod,InnerClasses,SourceFile,LineNumberTable

# Jetpack Compose specific rules to prevent layout and runtime crashes
-keepclassmembers class * extends androidx.compose.runtime.Composer { *; }
-dontwarn androidx.compose.runtime.**

# Kotlin Coroutines & Flow optimization rules
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepnames class kotlinx.coroutines.android.AndroidExceptionPreHandler {}
-keep class kotlinx.coroutines.** { *; }

# Room Database keep rules (including KSP and entity serialization)
-keep class * extends androidx.room.RoomDatabase
-keepclassmembers class * extends androidx.room.RoomDatabase {
    <init>(...);
}
-keep class androidx.room.** { *; }
-dontwarn androidx.room.**

# Retrofit, OkHttp, and Moshi keep rules
-keepattributes Signature
-keepclassmembers class * {
    @retrofit2.http.* <methods>;
}
-keep class retrofit2.** { *; }
-dontwarn retrofit2.**
-keep class okhttp3.** { *; }
-dontwarn okhttp3.**

# Keep all App Domain Models to prevent serialization/deserialization failures
-keep class com.example.model.** { *; }
-keepclassmembers class com.example.model.** { *; }
