package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.windowsizeclass.WindowSizeClass
import androidx.compose.material3.windowsizeclass.WindowWidthSizeClass
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import com.example.model.AppConfiguration
import com.example.model.DynamicAppConfig

val LocalAppConfig = compositionLocalOf { AppConfiguration() }
val LocalWindowSizeClass = compositionLocalOf<WindowSizeClass?> { null }

fun createAppColorScheme(config: AppConfiguration = AppConfiguration()): androidx.compose.material3.ColorScheme {
    val primary = config.primaryColor
    val secondary = config.secondaryColor
    val tertiary = config.accentColor
    val text = config.textColor
    
    return lightColorScheme(
        primary = primary,
        onPrimary = if (primary.isDark()) Color.White else Color.Black,
        primaryContainer = primary.copy(alpha = 0.15f),
        onPrimaryContainer = primary,
        secondary = secondary,
        onSecondary = if (secondary.isDark()) Color.White else Color.Black,
        secondaryContainer = secondary.copy(alpha = 0.15f),
        onSecondaryContainer = secondary,
        tertiary = tertiary,
        onTertiary = if (tertiary.isDark()) Color.White else Color.Black,
        background = config.backgroundColor,
        onBackground = text,
        surface = config.surfaceColor,
        onSurface = text,
        surfaceVariant = Color(0xFFF1F5F9),
        onSurfaceVariant = text.copy(alpha = 0.7f),
        error = config.errorColor,
        onError = Color.White,
        outline = Color(0xFFE2E8F0),
        outlineVariant = Color(0xFFCBD5E1)
    )
}

fun Color.isDark(): Boolean {
    val luminance = 0.299 * red + 0.587 * green + 0.114 * blue
    return luminance < 0.5
}

private val LightColorScheme = createAppColorScheme()

@Composable
fun DynamicAppTheme(
    config: AppConfiguration = AppConfiguration(),
    windowSizeClass: WindowSizeClass? = null,
    content: @Composable () -> Unit
) {
    val dynamicScheme = createAppColorScheme(config)
    val dynamicTypography = createAppTypography(config.advancedFontSettings)

    CompositionLocalProvider(
        LocalAppConfig provides config,
        LocalWindowSizeClass provides windowSizeClass
    ) {
        MaterialTheme(
            colorScheme = dynamicScheme,
            typography = dynamicTypography,
            shapes = Shapes,
            content = content
        )
    }
}

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        shapes = Shapes,
        content = content
    )
}

