package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AppTextDark = Color(0xFF0F172A)
val AppTextSecondary = Color(0xFF475569)
val AppTextMuted = Color(0xFF94A3B8)
val AppLightBorder = Color(0xFFE2E8F0)
val AppGreenAccent = Color(0xFF22C55E)
val PremiumGoldPrimary = Color(0xFFF59E0B)
val PremiumGoldLight = Color(0xFFFEF3C7)
val PremiumNavyBgDeep = Color(0xFF0F172A)
val PremiumNavyCard = Color(0xFF1E293B)
val AppOrangePrimary = Color(0xFFF97316)
