package com.example.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.AdvancedFontSettings

val defaultTypography = Typography()

fun resolveFontFamily(name: String, fallback: FontFamily? = null): FontFamily {
    val familyName = name.lowercase().trim().replace(" ", "_")
    val fontResId = try {
        when (familyName) {
            "roboto" -> com.example.R.font.roboto
            "inter" -> com.example.R.font.inter
            "lato" -> com.example.R.font.lato
            "montserrat" -> com.example.R.font.montserrat
            "open_sans", "open sans" -> com.example.R.font.open_sans
            "poppins" -> com.example.R.font.poppins
            "playfair_display", "playfair display" -> com.example.R.font.playfair_display
            "lora" -> com.example.R.font.lora
            "merriweather" -> com.example.R.font.merriweather
            "nunito" -> com.example.R.font.nunito
            "raleway" -> com.example.R.font.raleway
            "ubuntu" -> com.example.R.font.ubuntu
            "source_sans_3", "source sans 3" -> com.example.R.font.source_sans_3
            "mukta" -> com.example.R.font.mukta
            "pt_sans", "pt sans" -> com.example.R.font.pt_sans
            "noto_sans", "noto sans" -> com.example.R.font.noto_sans
            "noto_sans_telugu" -> com.example.R.font.noto_sans_telugu
            "noto_serif_telugu" -> com.example.R.font.noto_serif_telugu
            "mallanna" -> com.example.R.font.mallanna
            "mandali" -> com.example.R.font.mandali
            "ramabhadra" -> com.example.R.font.ramabhadra
            "ramaraja" -> com.example.R.font.ramaraja
            else -> {
                val field = com.example.R.font::class.java.getField(familyName)
                field.getInt(null)
            }
        }
    } catch (e: Exception) {
        com.example.R.font.roboto
    }

    return try {
        FontFamily(
            Font(fontResId, FontWeight.Light),
            Font(fontResId, FontWeight.Normal),
            Font(fontResId, FontWeight.Medium),
            Font(fontResId, FontWeight.SemiBold),
            Font(fontResId, FontWeight.Bold)
        )
    } catch (e: Exception) {
        fallback ?: FontFamily.Default
    }
}

fun createAppTypography(settings: AdvancedFontSettings): Typography {
    val appBaseFamily = resolveFontFamily(settings.fontFamily)
    val headingFamily = resolveFontFamily(settings.headingFontFamily.ifBlank { settings.fontFamily }, appBaseFamily)
    val bodyFamily = resolveFontFamily(settings.bodyFontFamily.ifBlank { settings.fontFamily }, appBaseFamily)

    val headingWeight = when (settings.headingFontWeight) {
        "Light" -> FontWeight.Light
        "Regular" -> FontWeight.Normal
        "Medium" -> FontWeight.Medium
        "Semi-Bold" -> FontWeight.SemiBold
        "Bold" -> FontWeight.Bold
        "Extra-Bold" -> FontWeight.Black
        else -> FontWeight.Bold
    }

    val bodyWeight = when (settings.bodyFontWeight) {
        "Light" -> FontWeight.Light
        "Regular" -> FontWeight.Normal
        "Medium" -> FontWeight.Medium
        "Semi-Bold" -> FontWeight.SemiBold
        "Bold" -> FontWeight.Bold
        else -> when (settings.fontWeight) {
            "Light" -> FontWeight.Light
            "Medium" -> FontWeight.Medium
            "Semi-Bold" -> FontWeight.SemiBold
            "Bold" -> FontWeight.Bold
            else -> FontWeight.Normal
        }
    }

    val multiplier = when (settings.lineSpacing) {
        "Compact" -> 1.10f
        "Comfortable" -> 1.30f
        "Spacious" -> 1.50f
        else -> 1.18f
    }

    val scale = settings.typographyScale.coerceIn(0.75f, 1.35f)
    val letterSpacing = (settings.letterSpacingScale).sp

    val titleSz = settings.titleFontSize * scale
    val headingSz = settings.headingFontSize * scale
    val bodySz = settings.bodyFontSize * scale
    val questionSz = settings.questionFontSize * scale
    val optionSz = settings.optionFontSize * scale
    val explanationSz = settings.explanationFontSize * scale
    val caSz = settings.currentAffairsFontSize * scale
    val buttonSz = settings.buttonFontSize * scale
    val labelSz = settings.labelFontSize * scale

    return Typography(
        displayLarge = TextStyle(
            fontFamily = headingFamily,
            fontWeight = headingWeight,
            fontSize = (titleSz * 1.4f).sp,
            lineHeight = (titleSz * 1.4f * multiplier).sp,
            letterSpacing = (settings.letterSpacingScale - 0.5f).sp
        ),
        displayMedium = TextStyle(
            fontFamily = headingFamily,
            fontWeight = headingWeight,
            fontSize = (titleSz * 1.2f).sp,
            lineHeight = (titleSz * 1.2f * multiplier).sp,
            letterSpacing = letterSpacing
        ),
        displaySmall = TextStyle(
            fontFamily = headingFamily,
            fontWeight = headingWeight,
            fontSize = titleSz.sp,
            lineHeight = (titleSz * multiplier).sp,
            letterSpacing = letterSpacing
        ),
        headlineLarge = TextStyle(
            fontFamily = headingFamily,
            fontWeight = headingWeight,
            fontSize = titleSz.sp,
            lineHeight = (titleSz * multiplier).sp,
            letterSpacing = letterSpacing
        ),
        headlineMedium = TextStyle(
            fontFamily = headingFamily,
            fontWeight = headingWeight,
            fontSize = headingSz.sp,
            lineHeight = (headingSz * multiplier).sp,
            letterSpacing = letterSpacing
        ),
        headlineSmall = TextStyle(
            fontFamily = headingFamily,
            fontWeight = headingWeight,
            fontSize = (headingSz * 0.9f).sp,
            lineHeight = (headingSz * 0.9f * multiplier).sp,
            letterSpacing = letterSpacing
        ),
        titleLarge = TextStyle(
            fontFamily = headingFamily,
            fontWeight = headingWeight,
            fontSize = headingSz.sp,
            lineHeight = (headingSz * multiplier).sp,
            letterSpacing = letterSpacing
        ),
        titleMedium = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = FontWeight.SemiBold,
            fontSize = questionSz.sp,
            lineHeight = (questionSz * multiplier).sp,
            letterSpacing = letterSpacing
        ),
        titleSmall = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = bodyWeight,
            fontSize = caSz.sp,
            lineHeight = (caSz * multiplier).sp,
            letterSpacing = (settings.letterSpacingScale + 0.1f).sp
        ),
        bodyLarge = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = bodyWeight,
            fontSize = questionSz.sp,
            lineHeight = (questionSz * multiplier).sp,
            letterSpacing = (settings.letterSpacingScale + 0.3f).sp
        ),
        bodyMedium = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = bodyWeight,
            fontSize = explanationSz.sp,
            lineHeight = (explanationSz * multiplier).sp,
            letterSpacing = (settings.letterSpacingScale + 0.2f).sp
        ),
        bodySmall = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = bodyWeight,
            fontSize = optionSz.sp,
            lineHeight = (optionSz * multiplier).sp,
            letterSpacing = letterSpacing
        ),
        labelLarge = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = FontWeight.Medium,
            fontSize = buttonSz.sp,
            lineHeight = (buttonSz * multiplier).sp,
            letterSpacing = (settings.letterSpacingScale + 0.2f).sp
        ),
        labelMedium = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = FontWeight.Medium,
            fontSize = labelSz.sp,
            lineHeight = (labelSz * multiplier).sp,
            letterSpacing = (settings.letterSpacingScale + 0.4f).sp
        ),
        labelSmall = TextStyle(
            fontFamily = bodyFamily,
            fontWeight = FontWeight.Medium,
            fontSize = (labelSz * 0.9f).sp,
            lineHeight = (labelSz * 0.9f * multiplier).sp,
            letterSpacing = (settings.letterSpacingScale + 0.4f).sp
        )
    )
}

val Typography = defaultTypography
