package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.material3.windowsizeclass.ExperimentalMaterial3WindowSizeClassApi
import androidx.compose.material3.windowsizeclass.calculateWindowSizeClass
import androidx.compose.material3.Surface
import androidx.compose.material3.MaterialTheme
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.example.worker.NotificationScheduler
import android.Manifest
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.SampleData
import com.example.db.AppDatabase
import com.example.model.*
import com.example.repository.AppRepository
import com.example.repository.AppConfigRepository
import com.example.ui.components.AppMotionSystem
import com.example.ui.components.PremiumScreenSurface
import com.example.ui.components.ScientificCalculatorDialog
import com.example.ui.screens.*
import com.example.ui.theme.DynamicAppTheme
import com.example.viewmodel.PracticeStateViewModel
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import com.example.util.BillingPaymentManager
import com.example.util.PermissionManager
import com.razorpay.PaymentResultListener
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity(), PaymentResultListener {
    override fun onPaymentSuccess(razorpayPaymentId: String?) {
        BillingPaymentManager.onRazorpaySuccess(razorpayPaymentId ?: "")
    }

    override fun onPaymentError(errorCode: Int, response: String?) {
        BillingPaymentManager.onRazorpayError(errorCode, response)
    }

    @OptIn(ExperimentalMaterial3WindowSizeClassApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val windowSizeClass = calculateWindowSizeClass(this)
            val context = LocalContext.current
            var isInitTaskDone by remember { mutableStateOf(false) }
            var isAnimFinished by remember { mutableStateOf(false) }
            var isInitializing by remember { mutableStateOf(true) }
            
            LaunchedEffect(isInitTaskDone, isAnimFinished) {
                if (isInitTaskDone && isAnimFinished) {
                    isInitializing = false
                }
            }

            // Global safety timer: GUARANTEES the splash transition finishes within 2500ms under any network/device condition
            LaunchedEffect(Unit) {
                kotlinx.coroutines.delay(2500)
                isInitTaskDone = true
                isAnimFinished = true
                isInitializing = false
            }

            // Initialize FCM Push Notifications & Firebase Services & Bundled JSON Data
            LaunchedEffect(Unit) {

                try {
                    // 0. Coordinate dynamic AppConfig & TenantConfig immediately to apply branding, theme, and feature flags before dashboard renders
                    val tenantInitResult = com.example.util.TenantInitializationManager.initializeTenant(
                        context = context,
                        timeoutMs = 2000L
                    )
                    android.util.Log.i("MainActivity", "TenantInitializationManager completed: ${tenantInitResult.appName} (${tenantInitResult.source})")

                    com.example.util.AdminSessionManager.context = context.applicationContext
                    com.example.util.FirebaseSyncManager.initializeFcm(context)
                    com.example.util.PurchaseObserver.initialize(context)
                    com.example.util.UserPreferencesManager.initialize(context)
                    com.example.util.AnalyticsManager.initialize(context, com.example.util.AppConfigProvider.appId)
                    
                    // Load and parse bundled configurations safely
                    val buildAppId = com.example.util.AppConfigProvider.appId
                    SampleData.setActiveApp(buildAppId)

                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        try {
                            SampleData.loadAppsConfigJson(context)
                            SampleData.loadBundledHierarchyJson(context)
                        } catch (e: Exception) {
                            android.util.Log.w("MainActivity", "Bundled data loading note: ${e.message}")
                        }

                        // Room Database Caching for Core App Data (Subjects & Current Affairs)
                        try {
                            val db = com.example.db.AppDatabase.getDatabase(context)
                            val repo = com.example.repository.AppRepository(db, buildAppId)
                            val subjects = try { SampleData.subjectsState.toList() } catch (e: Exception) { emptyList() }
                            val currentAffairs = try { SampleData.currentAffairsState.toList() } catch (e: Exception) { emptyList() }
                            if (subjects.isNotEmpty() || currentAffairs.isNotEmpty()) {
                                repo.syncInitialCacheIfEmpty(
                                    subjects = subjects,
                                    currentAffairs = currentAffairs
                                )
                                android.util.Log.d("MainActivity", "Core app data cached in Room database for offline access")
                            }
                        } catch (e: Exception) {
                            android.util.Log.e("MainActivity", "Error caching core data in Room: ${e.message}")
                        }
                    }
                } catch (t: Throwable) {
                    android.util.Log.e("MainActivity", "Error during app services initialization: ${t.message}", t)
                }

                // RESTORE FIREBASE AUTH SESSION AT APP STARTUP
                try {
                    val currentUser = com.example.util.FirebaseSyncManager.auth.currentUser
                    if (currentUser != null) {
                        val userEmail = currentUser.email ?: ""
                        if (userEmail.isNotBlank()) {
                            com.example.util.FirebaseSyncManager.fetchUserProfileFromFirestore(
                                email = userEmail,
                                onSuccess = { profile ->
                                    SampleData.sampleUserProfile = profile.copy(isLoggedIn = true)
                                    isInitTaskDone = true
                                },
                                onFailure = {
                                    // Fallback: user exists in Auth but not in Firestore yet, create default
                                    val currentAppName = SampleData.getActiveApp().name
                                    val defaultProfile = SampleData.sampleUserProfile.copy(
                                        name = currentUser.displayName ?: "$currentAppName Aspirant",
                                        email = userEmail,
                                        isLoggedIn = true
                                    )
                                    SampleData.sampleUserProfile = defaultProfile
                                    com.example.util.FirebaseSyncManager.syncUserProfileToFirestore(defaultProfile)
                                    isInitTaskDone = true
                                }
                            )
                        } else {
                            // Anonymous or phone user
                            val defaultProfile = SampleData.sampleUserProfile.copy(
                                        name = "Anonymous Aspirant",
                                        email = "anonymous@exam.portal",
                                        isLoggedIn = true
                                    )
                            SampleData.sampleUserProfile = defaultProfile
                            isInitTaskDone = true
                        }
                    } else {
                        // Set default profile logged out
                        SampleData.sampleUserProfile = SampleData.sampleUserProfile.copy(isLoggedIn = false)
                        isInitTaskDone = true
                    }
                } catch (t: Throwable) {
                    android.util.Log.e("MainActivity", "Firebase Auth restore error: ${t.message}", t)
                    SampleData.sampleUserProfile = SampleData.sampleUserProfile.copy(isLoggedIn = false)
                    isInitTaskDone = true
                }
            }

            val configRepository = remember { 
                AppConfigRepository.getInstance().apply {
                    initializeWithContext(context)
                }
            }
            val appConfig by configRepository.currentAppConfig.collectAsStateWithLifecycle()

            DynamicAppTheme(config = appConfig, windowSizeClass = windowSizeClass) {
                PremiumScreenSurface {
                    androidx.compose.animation.Crossfade(
                        targetState = isInitializing,
                        animationSpec = androidx.compose.animation.core.tween(700),
                        label = "splash_transition"
                    ) { loading ->
                        if (loading) {
                            androidx.activity.compose.BackHandler {
                                // Consume system back button during splash screen to keep the app open
                            }
                            AppSplashScreen(onLoadingFinished = {
                                isAnimFinished = true
                                isInitializing = false
                            })
                        } else {
                            val context = LocalContext.current
                    val database = remember { AppDatabase.getDatabase(context) }
                    val repository = remember(appConfig.appId) { AppRepository(database, appConfig.appId) }
                    val coroutineScope = rememberCoroutineScope()

                    val testResults by repository.allTestResults.collectAsStateWithLifecycle(initialValue = emptyList())
                    val bookmarkedQuestions by repository.allBookmarks.collectAsStateWithLifecycle(initialValue = emptyList())
                    val generatedMockTests by repository.allMockTests.collectAsStateWithLifecycle(initialValue = emptyList())
                    val allQuestions by repository.allQuestions.collectAsStateWithLifecycle(initialValue = emptyList())
                    val userProgress by repository.userProgress.collectAsStateWithLifecycle(initialValue = repository.userProgress.value)
                    val allLegalDocs by repository.allLegalDocuments.collectAsStateWithLifecycle(initialValue = emptyList())
                    val allFaqs by repository.allFaqs.collectAsStateWithLifecycle(initialValue = emptyList())


                    val isLoggedIn = SampleData.sampleUserProfile.isLoggedIn
                    // Permissions are now requested just-in-time when the user enables features requiring them.

                    LaunchedEffect(allQuestions.isEmpty()) {
                        if (allQuestions.isEmpty()) {
                            val defaultQs = com.example.data.SampleData.questionsState.filter { it.appId == appConfig.appId }
                            if (defaultQs.isNotEmpty()) {
                                repository.saveQuestions(defaultQs)
                            }
                        }
                    }

                    LaunchedEffect(allLegalDocs.isEmpty()) {
                        if (allLegalDocs.isEmpty()) {
                            com.example.data.SampleData.getDefaultLegalDocs().forEach {
                                repository.saveLegalDocument(it)
                            }
                        }
                    }

                    LaunchedEffect(allFaqs.isEmpty()) {
                        if (allFaqs.isEmpty()) {
                            com.example.data.SampleData.getDefaultFaqs().forEach {
                                repository.saveSupportFaq(it)
                            }
                        }
                    }

                    // Clear and re-sync SampleData states when appId changes to prevent bleed-over
                    LaunchedEffect(appConfig.appId) {
                        SampleData.generatedMockTestsState.clear()
                    }

                    // Sync SampleData.generatedMockTestsState with Room if empty
                    LaunchedEffect(generatedMockTests, appConfig.appId) {
                        if (generatedMockTests.isNotEmpty()) {
                            // First clear if we are starting a fresh sync for this appId
                            if (SampleData.generatedMockTestsState.isNotEmpty() && 
                                SampleData.generatedMockTestsState.any { it.appId != appConfig.appId }) {
                                SampleData.generatedMockTestsState.clear()
                            }
                            
                            generatedMockTests.forEach { test ->
                                if (!SampleData.generatedMockTestsState.any { it.id == test.id }) {
                                    SampleData.generatedMockTestsState.add(test)
                                }
                            }
                        }
                    }

                    // Force navigation and state reset when appId changes
                    key(appConfig.appId) {
                        val navController = rememberNavController()
                        val practiceViewModel = remember { PracticeStateViewModel.getInstance() }

                        var selectedSubject by remember { mutableStateOf<Subject?>(null) }
                        var selectedMockTestId by remember { mutableStateOf<String?>(null) }
                        var selectedUnit by remember { mutableStateOf<UnitModel?>(null) }
                        var selectedTopic by remember { mutableStateOf<TopicModel?>(null) }
                        var activePracticeQuestions by remember { mutableStateOf<List<Question>>(emptyList()) }
                        var activePracticeTitle by remember { mutableStateOf("Practice Arena") }
                        var activePracticeShowCelebration by remember { mutableStateOf(false) }
                        var activePracticeId by remember { mutableStateOf("practice-session-default") }

                        // Sets / Subtopics Context Tracking
                        var currentContextSets by remember { mutableStateOf<List<PracticeSetModel>>(emptyList()) }
                        var currentSetIndex by remember { mutableIntStateOf(0) }

                        // Test Results State
                        var testScore by remember { mutableDoubleStateOf(0.0) }
                        var testCorrect by remember { mutableIntStateOf(0) }
                        var testWrong by remember { mutableIntStateOf(0) }
                        var testUserAnswers by remember { mutableStateOf<Map<String, String>>(emptyMap()) }

                        // ScientificCalculator State
                        var showScientificCalculator by remember { mutableStateOf(false) }

                        if (showScientificCalculator) {
                            ScientificCalculatorDialog(onDismiss = { showScientificCalculator = false })
                        }

                        // Handle notification click routing
                        LaunchedEffect(Unit) {
                            val targetDest = intent?.getStringExtra(com.example.worker.DailyPracticeReminderWorker.EXTRA_NAVIGATE_TO)
                            if (!targetDest.isNullOrBlank()) {
                                when (targetDest) {
                                    com.example.worker.DailyPracticeReminderWorker.NAV_DEST_DAILY_QUIZ -> {
                                        navController.navigate("daily_quiz")
                                    }
                                    com.example.worker.DailyPracticeReminderWorker.NAV_DEST_PRACTICE -> {
                                        navController.navigate("mock_tests")
                                    }
                                    com.example.worker.DailyPracticeReminderWorker.NAV_DEST_ANALYTICS -> {
                                        navController.navigate("profile")
                                    }
                                }
                            }
                        }

                        val navigateToHome: () -> Unit = {
                            // Clear all temporary practice / syllabus / mock test selection state via shared PracticeStateViewModel
                            practiceViewModel.resetPracticeContext()
                            selectedSubject = null
                            selectedUnit = null
                            selectedTopic = null
                            activePracticeQuestions = emptyList()
                            activePracticeTitle = "Practice Arena"
                            activePracticeShowCelebration = false
                            activePracticeId = "practice-session-default"
                            currentContextSets = emptyList()
                            currentSetIndex = 0
                            selectedMockTestId = null

                            // Pop the navigation stack back to home as the clean root destination
                            val popped = navController.popBackStack("home", inclusive = false)
                            if (!popped) {
                                navController.navigate("home") {
                                    popUpTo(navController.graph.startDestinationId) { inclusive = false }
                                    launchSingleTop = true
                                }
                            }
                        }

                        // Determine start destination based on authentication & admin status
                        val userProfile by SampleData.userProfileState
                        val isAdminLoggedIn = remember(userProfile.role) { 
                            com.example.util.AdminSessionManager.isAdminLoggedIn(context) && userProfile.role == com.example.model.UserRole.ADMIN
                        }
                        val startDestination = if (userProfile.isLoggedIn) {
                            "home"
                        } else {
                            "login"
                        }

                        // Enforce login-first authentication wall and instant redirection on logout
                        LaunchedEffect(userProfile.isLoggedIn) {
                            if (!userProfile.isLoggedIn) {
                                val currentRoute = navController.currentBackStackEntry?.destination?.route
                                if (currentRoute != null && currentRoute != "login") {
                                    navController.navigate("login") {
                                        popUpTo(navController.graph.startDestinationId) { inclusive = false }
                                        launchSingleTop = true
                                    }
                                }
                            }
                        }

                        // Force regular users to the build-specific app ID
                        LaunchedEffect(isAdminLoggedIn) {
                            if (!isAdminLoggedIn) {
                                val buildAppId = com.example.util.AppConfigProvider.appId
                                if (SampleData.currentActiveAppId.value != buildAppId) {
                                    SampleData.setActiveApp(buildAppId)
                                    configRepository.switchActiveAppTenant(buildAppId)
                                }
                            }
                        }

                        NavHost(
                            navController = navController,
                            startDestination = startDestination,
                            enterTransition = { AppMotionSystem.enterTransition() },
                            exitTransition = { AppMotionSystem.exitTransition() },
                            popEnterTransition = { AppMotionSystem.popEnterTransition() },
                            popExitTransition = { AppMotionSystem.popExitTransition() }
                        ) {
                            composable("app_selection") {
                                LaunchedEffect(Unit) {
                                    navController.navigate("home") {
                                        popUpTo("app_selection") { inclusive = true }
                                    }
                                }
                            }
                            composable("home") {
                            LaunchedEffect(Unit) {
                                practiceViewModel.resetPracticeContext()
                            }
                            HomeScreen(
                                onNavigateToSubject = { subject ->
                                    practiceViewModel.setHierarchy(subject = subject)
                                    selectedSubject = subject
                                    selectedUnit = null
                                    selectedTopic = null
                                    navController.navigate("syllabus")
                                },
                                onNavigateToUnit = { subject, unit ->
                                    practiceViewModel.setHierarchy(subject = subject, unit = unit)
                                    selectedSubject = subject
                                    selectedUnit = unit
                                    selectedTopic = null
                                    navController.navigate("syllabus")
                                },
                                onNavigateToTopic = { subject, unit, topic ->
                                    practiceViewModel.setHierarchy(subject = subject, unit = unit, topic = topic)
                                    selectedSubject = subject
                                    selectedUnit = unit
                                    selectedTopic = topic
                                    navController.navigate("sets")
                                },
                                onNavigateToCurrentAffairs = { navController.navigate("current_affairs") },
                                onNavigateToPerformance = { navController.navigate("performance") },
                                onNavigateToSubscription = { navController.navigate("subscription") },
                                onNavigateToScientificCalculator = { showScientificCalculator = true },
                                onNavigateToPrivacy = { navController.navigate("privacy") },
                                onNavigateToPrivacySection = { section -> navController.navigate("privacy/$section") },
                                onNavigateToMockTests = { navController.navigate("available_mock_tests") },
                                onNavigateToMockTestGenerator = { navController.navigate("mock_test_generator") },
                                onNavigateToAvailableMockTests = { navController.navigate("available_mock_tests") },
                                onNavigateToDailyQuiz = { navController.navigate("daily_quiz") },
                                onNavigateToProfile = { navController.navigate("profile") },
                                onNavigateToLogin = { navController.navigate("login") },
                                onNavigateToSavedQuestions = { navController.navigate("saved_questions") },
                                onNavigateToAdminDashboard = { navController.navigate("admin_dashboard") },
                                onNavigateToFontSettings = { navController.navigate("advanced_font_settings") },
                                onNavigateToLeaderboard = { navController.navigate("leaderboard") },
                                onNavigateToOfflineManager = { navController.navigate("offline_manager") },
                                onNavigateToNotifications = { navController.navigate("notifications") },
                                onNavigateToAppSelection = { navController.navigate("admin_dashboard") }
                            )
                        }

                        composable("admin_dashboard") {
                            AdminDashboardScreen(
                                onSwitchToUserPage = {
                                    navController.navigate("home") {
                                        popUpTo("home") { inclusive = true }
                                    }
                                },
                                onLogoutToHome = {
                                    navController.navigate("home") {
                                        popUpTo("home") { inclusive = true }
                                    }
                                },
                                onLogoutToLogin = {
                                    navController.navigate("login") {
                                        popUpTo("home") { inclusive = false }
                                    }
                                },
                                onNavigateToSubscription = { navController.navigate("subscription") }
                            )
                        }

                        composable("login") {
                            LoginScreen(
                                onLoginSuccess = {
                                    navController.navigate("home") {
                                        popUpTo("login") { inclusive = true }
                                    }
                                },
                                onBack = {
                                    if (navController.previousBackStackEntry != null) {
                                        navController.popBackStack()
                                    }
                                },
                                onNavigateToAdminDashboard = {
                                    navController.navigate("admin_dashboard")
                                }
                            )
                        }

                        composable("syllabus") {
                            val subj = selectedSubject ?: SampleData.defaultSubjects[0]
                            SyllabusExplorerScreen(
                                subject = subj,
                                initialUnit = selectedUnit,
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome,
                                onSelectTopic = { unit, topic ->
                                    selectedUnit = unit
                                    selectedTopic = topic
                                    navController.navigate("sets")
                                },
                                onSelectSubjectSets = { _ ->
                                    selectedUnit = null
                                    selectedTopic = null
                                    navController.navigate("sets")
                                },
                                onSelectUnitSets = { unit ->
                                    selectedUnit = unit
                                    selectedTopic = null
                                    navController.navigate("sets")
                                },
                                onNavigateToSubscription = {
                                    navController.navigate("subscription")
                                }
                            )
                        }

                        composable("sets") {
                            val subj = selectedSubject ?: SampleData.defaultSubjects[0]
                            val u = selectedUnit
                            val t = selectedTopic
                            TopicSetsScreen(
                                subject = subj,
                                unit = u,
                                topic = t,
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome,
                                onStartSet = { pSet, allSets ->
                                    val qList = pSet.questions.ifEmpty {
                                        SampleData.getQuestionsForPractice(subj.id, u?.id ?: "", t?.id ?: "", "")
                                    }
                                    val pTitle = "${t?.name ?: subj.name} • ${pSet.title}"
                                    practiceViewModel.setPracticeSet(pSet, allSets)
                                    practiceViewModel.startPracticeSession(
                                        id = pSet.id,
                                        title = pTitle,
                                        questions = qList,
                                        showCelebration = true
                                    )
                                    currentContextSets = allSets
                                    currentSetIndex = allSets.indexOfFirst { it.id == pSet.id }.coerceAtLeast(0)
                                    activePracticeQuestions = qList
                                    activePracticeTitle = pTitle
                                    activePracticeShowCelebration = true
                                    activePracticeId = pSet.id
                                    navController.navigate("practice")
                                },
                                testResults = testResults,
                                onNavigateToSubscription = {
                                    navController.navigate("subscription")
                                }
                            )
                        }

                        composable("practice") {
                            PracticeArenaScreen(
                                practiceSessionId = activePracticeId,
                                questions = activePracticeQuestions,
                                title = activePracticeTitle,
                                positiveMarks = 1.0,
                                negativeMarks = 1.0,
                                initialBookmarkedIds = bookmarkedQuestions.map { it.id }.toSet(),
                                onToggleBookmark = { question ->
                                    repository.toggleBookmark(question)
                                },
                                onNavigateToHome = navigateToHome,
                                onBack = { navController.popBackStack() },
                                isMockTest = activePracticeId.startsWith("mock-") || activePracticeId.contains("mock"),
                                showCelebration = activePracticeShowCelebration,
                                onSubmitTest = { correct, wrong, score, userAnswers, timeTaken ->
                                    testCorrect = correct
                                    testWrong = wrong
                                    testScore = score
                                    testUserAnswers = userAnswers
                                    coroutineScope.launch {
                                        val total = activePracticeQuestions.size
                                        val unanswered = (total - (correct + wrong)).coerceAtLeast(0)
                                        val pct = if (total > 0) ((correct * 100f) / total) else 0f
                                        val accuracy = if (correct + wrong > 0) "${((correct * 100) / (correct + wrong))}%" else "0%"
                                        repository.saveTestResult(
                                            testTitle = activePracticeTitle,
                                            totalQuestions = total,
                                            correctCount = correct,
                                            wrongCount = wrong,
                                            unansweredCount = unanswered,
                                            percentage = pct,
                                            accuracyStr = accuracy,
                                            timeSeconds = timeTaken
                                        )
                                        // Update verified Leaderboard scoring and XP
                                        com.example.repository.LeaderboardRepository.getInstance(this@MainActivity)
                                            .processVerifiedTestResult(
                                                testId = activePracticeId,
                                                testTitle = activePracticeTitle,
                                                totalQuestions = total,
                                                correctAnswers = correct,
                                                percentage = pct,
                                                timeSeconds = timeTaken,
                                                subjectId = selectedSubject?.id ?: ""
                                            )
                                    }
                                    navController.navigate("result") {
                                        popUpTo("practice") { inclusive = true }
                                    }
                                }
                            )
                        }

                        composable("result") {
                                val nextIdx = currentSetIndex + 1
                                val hasNext = nextIdx in currentContextSets.indices
                                val nextSetItem = if (hasNext) currentContextSets[nextIdx] else null
                                val isCurrentSubtopic = activePracticeId.startsWith("subtopic-") ||
                                    (currentContextSets.isNotEmpty() && currentContextSets.any { it.id.startsWith("subtopic-") }) ||
                                    (activePracticeQuestions.isNotEmpty() && activePracticeQuestions.all { it.subtopic.isNotBlank() && it.subtopic.equals(activePracticeQuestions.first().subtopic, ignoreCase = true) })

                                ResultScreen(
                                    questions = activePracticeQuestions,
                                    userAnswers = testUserAnswers,
                                    correctCount = testCorrect,
                                    wrongCount = testWrong,
                                    score = testScore,
                                    initialBookmarkedIds = bookmarkedQuestions.map { it.id }.toSet(),
                                    onToggleBookmark = { question ->
                                        repository.toggleBookmark(question)
                                    },
                                    onPracticeAgain = {
                                        // 1. Delete persistent saved practice session
                                        com.example.util.PracticeSessionManager.deleteSession(this@MainActivity, activePracticeId)
                                        // 2. Reset user score, answers, and counters
                                        testUserAnswers = emptyMap()
                                        testCorrect = 0
                                        testWrong = 0
                                        testScore = 0.0
                                        // 3. Shuffle questions and randomly shuffle options
                                        activePracticeQuestions = activePracticeQuestions.map { it.shuffledOptions() }.shuffled(java.security.SecureRandom())
                                        // 4. Update session ID with fresh timestamp to ensure completely isolated session
                                        activePracticeId = "fresh_${System.currentTimeMillis()}_${activePracticeId.substringBefore("_fresh")}"
                                        // 5. Navigate to practice cleanly
                                        navController.navigate("practice") {
                                            popUpTo("result") { inclusive = true }
                                        }
                                    },
                                    onNextSet = if (hasNext && nextSetItem != null) {
                                        {
                                            currentSetIndex = nextIdx
                                            val nextSet = nextSetItem
                                            val subj = selectedSubject ?: SampleData.defaultSubjects[0]
                                            val u = selectedUnit
                                            val t = selectedTopic
                                            val qList = nextSet.questions.ifEmpty {
                                                SampleData.getQuestionsForPractice(subj.id, u?.id ?: "", t?.id ?: "", "")
                                            }
                                            val pTitle = "${t?.name ?: subj.name} • ${nextSet.title}"
                                            activePracticeQuestions = qList
                                            activePracticeTitle = pTitle
                                            activePracticeShowCelebration = true
                                            activePracticeId = nextSet.id
                                            practiceViewModel.startPracticeSession(
                                                id = nextSet.id,
                                                title = pTitle,
                                                questions = qList,
                                                showCelebration = true
                                            )
                                            navController.navigate("practice") {
                                                popUpTo("result") { inclusive = true }
                                            }
                                        }
                                    } else null,
                                    nextItemTitle = nextSetItem?.title,
                                    isSubtopicPractice = isCurrentSubtopic,
                                    hasNextItem = hasNext,
                                    onBackToPrevious = {
                                        navController.popBackStack()
                                    },
                                    onBackToHome = navigateToHome
                                )
                            }

                        composable("saved_questions") {
                            SavedQuestionsScreen(
                                savedQuestions = bookmarkedQuestions,
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome,
                                onRemoveBookmark = { questionId ->
                                    coroutineScope.launch {
                                        repository.removeBookmark(questionId)
                                    }
                                },
                                onPracticeSaved = { questions, title ->
                                    activePracticeQuestions = questions
                                    activePracticeTitle = title
                                    activePracticeId = "saved-${title.hashCode()}"
                                    navController.navigate("practice")
                                },
                                onNavigateToExplore = {
                                    navController.navigate("home")
                                }
                            )
                        }

                        composable("current_affairs") {
                            CurrentAffairsScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome,
                                onNavigateToPractice = { subjectId, monthId, setId, level ->
                                    val ca = SampleData.monthlyCurrentAffairsState.find { it.id == monthId }
                                    val set = ca?.sets?.find { it.id == setId }
                                    if (set != null) {
                                        activePracticeQuestions = set.questions
                                        activePracticeTitle = "${ca.month} ${ca.year} • ${set.title}"
                                        activePracticeShowCelebration = true
                                        activePracticeId = "ca-${monthId}-${setId}"
                                        navController.navigate("practice")
                                    }
                                },
                                onNavigateToSubscription = {
                                    navController.navigate("subscription")
                                }
                            )
                        }

                        composable("performance") {
                            PerformanceBoardScreen(
                                results = testResults,
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome,
                                onNavigateToPractice = { subjectId ->
                                    val sub = SampleData.subjectsState.find { it.id == subjectId } ?: SampleData.defaultSubjects.firstOrNull()
                                    if (sub != null) {
                                        selectedSubject = sub
                                        selectedUnit = sub.units.firstOrNull()
                                        selectedTopic = selectedUnit?.topics?.firstOrNull()
                                        navController.navigate("sets")
                                    }
                                }
                            )
                        }

                        composable("subscription") {
                            SubscriptionScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome
                            )
                        }

                        composable("course_enrollment") {
                            CourseEnrollmentCheckoutScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome,
                                onEnrollmentSuccess = { _, _ ->
                                    navController.popBackStack()
                                }
                            )
                        }

                        composable("razorpay_payment") {
                            RazorpayPaymentScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome
                            )
                        }

                        composable("privacy") {
                            LegalSupportCenterScreen(
                                initialSection = null,
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome
                            )
                        }

                        composable("privacy/{section}") { backStackEntry ->
                            val section = backStackEntry.arguments?.getString("section")
                            LegalSupportCenterScreen(
                                initialSection = section,
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome
                            )
                        }

                        composable("legal/{section}") { backStackEntry ->
                            val section = backStackEntry.arguments?.getString("section")
                            LegalSupportCenterScreen(
                                initialSection = section,
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome
                            )
                        }

                        composable("mock_test_execution") {
                            val activeApp = SampleData.getActiveApp()
                            val test = SampleData.generatedMockTestsState.find { it.id == selectedMockTestId }
                            if (test != null) {
                                com.example.ui.screens.FullLengthMockTestScreen(
                                    test = test,
                                    initialBookmarkedIds = bookmarkedQuestions.map { it.id }.toSet(),
                                    onToggleBookmark = { question ->
                                        repository.toggleBookmark(question)
                                    },
                                    onAnswerSelected = { newAnswers ->
                                        val testIndex = SampleData.generatedMockTestsState.indexOfFirst { it.id == test.id }
                                        if (testIndex != -1) {
                                            val currentTest = SampleData.generatedMockTestsState[testIndex]
                                            SampleData.generatedMockTestsState[testIndex] = currentTest.copy(
                                                status = "In Progress",
                                                userAnswers = newAnswers
                                            )
                                        }
                                    },
                                    onPauseTest = { currentIndex, remainingSeconds, timeTakenSeconds, markedForReview, skippedQuestions, userAnswers ->
                                        val testIndex = SampleData.generatedMockTestsState.indexOfFirst { it.id == test.id }
                                        if (testIndex != -1) {
                                            val currentTest = SampleData.generatedMockTestsState[testIndex]
                                            val updated = currentTest.copy(
                                                status = "In Progress",
                                                currentIndex = currentIndex,
                                                remainingSeconds = remainingSeconds,
                                                timeTakenSeconds = timeTakenSeconds,
                                                markedForReview = markedForReview,
                                                skippedQuestions = skippedQuestions,
                                                userAnswers = userAnswers
                                            )
                                            SampleData.generatedMockTestsState[testIndex] = updated
                                            repository.saveMockTest(updated)
                                        }
                                        navController.popBackStack()
                                    },
                                    onSubmitTest = { correct, wrong, score, userAnswers, timeTaken ->
                                        // Update test status
                                        val testIndex = SampleData.generatedMockTestsState.indexOfFirst { it.id == test.id }
                                        val pct = if (test.questions.isNotEmpty() && test.positiveMarks > 0) ((score / (test.questions.size * test.positiveMarks)) * 100.0).toFloat() else 0f
                                        val accuracy = if (correct + wrong > 0) "${((correct * 100) / (correct + wrong))}%" else "0%"
                                        val total = test.questions.size
                                        val unanswered = (total - (correct + wrong)).coerceAtLeast(0)

                                        if (testIndex != -1) {
                                            val currentTest = SampleData.generatedMockTestsState[testIndex]
                                            val newAttempt = com.example.model.MockTestAttemptRecord(
                                                attemptNumber = currentTest.attemptsHistory.size + 1,
                                                completedAt = System.currentTimeMillis(),
                                                score = score,
                                                totalMarks = currentTest.totalMarks,
                                                correctAnswers = correct,
                                                wrongAnswers = wrong,
                                                unanswered = unanswered,
                                                timeTakenSeconds = timeTaken,
                                                percentage = pct.toDouble(),
                                                accuracyStr = accuracy,
                                                userAnswers = userAnswers
                                            )
                                            val updated = currentTest.copy(
                                                status = "Completed",
                                                correctAnswers = correct,
                                                wrongAnswers = wrong,
                                                unanswered = unanswered,
                                                score = score,
                                                userAnswers = userAnswers,
                                                timeTakenSeconds = timeTaken,
                                                percentage = pct.toDouble(),
                                                attemptsHistory = currentTest.attemptsHistory + newAttempt
                                            )
                                            SampleData.generatedMockTestsState[testIndex] = updated
                                            repository.saveMockTest(updated)
                                        }

                                        // Persist into Room Database test_results & user_progress
                                        repository.saveTestResult(
                                            testTitle = test.title,
                                            totalQuestions = total,
                                            correctCount = correct,
                                            wrongCount = wrong,
                                            unansweredCount = unanswered,
                                            percentage = pct,
                                            accuracyStr = accuracy,
                                            timeSeconds = timeTaken,
                                            userAnswers = userAnswers,
                                            testType = "FULL_MOCK_TEST"
                                        )

                                        // Update verified Leaderboard scoring and XP
                                        coroutineScope.launch {
                                            com.example.repository.LeaderboardRepository.getInstance(this@MainActivity)
                                                .processVerifiedTestResult(
                                                    testId = test.id,
                                                    testTitle = test.title,
                                                    totalQuestions = total,
                                                    correctAnswers = correct,
                                                    percentage = pct,
                                                    timeSeconds = timeTaken,
                                                    subjectId = ""
                                                )
                                        }

                                        navController.navigate("mock_test_result") {
                                            popUpTo("mock_test_execution") { inclusive = true }
                                        }
                                    },
                                    onNavigateToSubscription = {
                                        navController.navigate("subscription")
                                    }
                                )
                            } else {
                                navController.popBackStack()
                            }
                        }

                        composable("mock_test_result") {
                            val test = SampleData.generatedMockTestsState.find { it.id == selectedMockTestId }
                            if (test != null) {
                                MockTestResultScreen(
                                    test = test,
                                    onBack = { navController.popBackStack() },
                                    onNavigateToHome = navigateToHome
                                )
                            } else {
                                navController.popBackStack()
                            }
                        }

                        composable("mock_tests") {
                            com.example.ui.screens.AvailableMockTestsScreen(
                                onNavigateBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome,
                                onNavigateToGenerator = {
                                    navController.navigate("mock_test_generator")
                                },
                                onStartTest = { test ->
                                    selectedMockTestId = test.id
                                    navController.navigate("mock_test_execution")
                                },
                                onResumeTest = { test ->
                                    selectedMockTestId = test.id
                                    navController.navigate("mock_test_execution")
                                },
                                onReattemptTest = { test ->
                                    val testIndex = SampleData.generatedMockTestsState.indexOfFirst { it.id == test.id }
                                    if (testIndex != -1) {
                                        val currentTest = SampleData.generatedMockTestsState[testIndex]
                                        val updatedHistory = if (currentTest.status == "Completed" &&
                                            (currentTest.attemptsHistory.isEmpty() || currentTest.attemptsHistory.last().score != currentTest.score)) {
                                            val totalM = currentTest.totalQuestions * currentTest.positiveMarks
                                            val accuracy = if (currentTest.correctAnswers + currentTest.wrongAnswers > 0) {
                                                "${((currentTest.correctAnswers * 100) / (currentTest.correctAnswers + currentTest.wrongAnswers))}%"
                                            } else "0%"
                                            val record = com.example.model.MockTestAttemptRecord(
                                                attemptNumber = currentTest.attemptsHistory.size + 1,
                                                completedAt = System.currentTimeMillis(),
                                                score = currentTest.score ?: 0.0,
                                                totalMarks = if (totalM > 0) totalM else 100.0,
                                                correctAnswers = currentTest.correctAnswers,
                                                wrongAnswers = currentTest.wrongAnswers,
                                                unanswered = currentTest.unanswered,
                                                timeTakenSeconds = currentTest.timeTakenSeconds,
                                                percentage = currentTest.percentage ?: 0.0,
                                                accuracyStr = accuracy,
                                                userAnswers = currentTest.userAnswers
                                            )
                                            currentTest.attemptsHistory + record
                                        } else {
                                            currentTest.attemptsHistory
                                        }

                                        val updated = currentTest.copy(
                                            status = "Not Attempted",
                                            userAnswers = emptyMap(),
                                            markedForReview = emptySet(),
                                            skippedQuestions = emptySet(),
                                            currentIndex = 0,
                                            remainingSeconds = currentTest.durationMinutes * 60,
                                            score = 0.0,
                                            correctAnswers = 0,
                                            wrongAnswers = 0,
                                            unanswered = test.questions.size,
                                            timeTakenSeconds = 0,
                                            percentage = 0.0,
                                            attemptsHistory = updatedHistory
                                        )
                                        SampleData.generatedMockTestsState[testIndex] = updated
                                        repository.saveMockTest(updated)
                                    }
                                    selectedMockTestId = test.id
                                    navController.navigate("mock_test_execution")
                                },
                                onViewResult = { test ->
                                    selectedMockTestId = test.id
                                    navController.navigate("mock_test_result")
                                },
                                onNavigateToSubscription = {
                                    navController.navigate("subscription")
                                }
                            )
                        }
                        composable("mock_test_generator") {
                            com.example.ui.screens.MockTestGeneratorScreen(
                                onNavigateBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome,
                                onTestGenerated = { test ->
                                    SampleData.generatedMockTestsState.add(0, test)
                                    repository.saveMockTest(test)
                                },
                                pastTests = SampleData.generatedMockTestsState,
                                onStartGeneratedTest = { test ->
                                    selectedMockTestId = test.id
                                    navController.navigate("mock_test_execution")
                                },
                                onNavigateToAvailableTests = {
                                    navController.navigate("available_mock_tests")
                                },
                                onNavigateToSubscription = {
                                    navController.navigate("subscription")
                                }
                            )
                        }

                        composable("available_mock_tests") {
                            com.example.ui.screens.AvailableMockTestsScreen(
                                onNavigateBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome,
                                onNavigateToGenerator = {
                                    navController.navigate("mock_test_generator")
                                },
                                onStartTest = { test ->
                                    selectedMockTestId = test.id
                                    navController.navigate("mock_test_execution")
                                },
                                onResumeTest = { test ->
                                    selectedMockTestId = test.id
                                    navController.navigate("mock_test_execution")
                                },
                                onReattemptTest = { test ->
                                    val testIndex = SampleData.generatedMockTestsState.indexOfFirst { it.id == test.id }
                                    if (testIndex != -1) {
                                        val currentTest = SampleData.generatedMockTestsState[testIndex]
                                        val updatedHistory = if (currentTest.status == "Completed" &&
                                            (currentTest.attemptsHistory.isEmpty() || currentTest.attemptsHistory.last().score != currentTest.score)) {
                                            val totalM = currentTest.totalQuestions * currentTest.positiveMarks
                                            val accuracy = if (currentTest.correctAnswers + currentTest.wrongAnswers > 0) {
                                                "${((currentTest.correctAnswers * 100) / (currentTest.correctAnswers + currentTest.wrongAnswers))}%"
                                            } else "0%"
                                            val record = com.example.model.MockTestAttemptRecord(
                                                attemptNumber = currentTest.attemptsHistory.size + 1,
                                                completedAt = System.currentTimeMillis(),
                                                score = currentTest.score ?: 0.0,
                                                totalMarks = if (totalM > 0) totalM else 100.0,
                                                correctAnswers = currentTest.correctAnswers,
                                                wrongAnswers = currentTest.wrongAnswers,
                                                unanswered = currentTest.unanswered,
                                                timeTakenSeconds = currentTest.timeTakenSeconds,
                                                percentage = currentTest.percentage ?: 0.0,
                                                accuracyStr = accuracy,
                                                userAnswers = currentTest.userAnswers
                                            )
                                            currentTest.attemptsHistory + record
                                        } else {
                                            currentTest.attemptsHistory
                                        }

                                        val updated = currentTest.copy(
                                            status = "Not Attempted",
                                            userAnswers = emptyMap(),
                                            markedForReview = emptySet(),
                                            skippedQuestions = emptySet(),
                                            currentIndex = 0,
                                            remainingSeconds = currentTest.durationMinutes * 60,
                                            score = 0.0,
                                            correctAnswers = 0,
                                            wrongAnswers = 0,
                                            unanswered = test.questions.size,
                                            timeTakenSeconds = 0,
                                            percentage = 0.0,
                                            attemptsHistory = updatedHistory
                                        )
                                        SampleData.generatedMockTestsState[testIndex] = updated
                                        repository.saveMockTest(updated)
                                    }
                                    selectedMockTestId = test.id
                                    navController.navigate("mock_test_execution")
                                },
                                onViewResult = { test ->
                                    selectedMockTestId = test.id
                                    navController.navigate("mock_test_result")
                                },
                                onNavigateToSubscription = {
                                    navController.navigate("subscription")
                                }
                            )
                        }

                        composable("daily_quiz") {
                            DailyQuizScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome,
                                onStartDailyQuiz = { questions ->
                                    activePracticeQuestions = questions
                                    activePracticeTitle = "Daily Quiz Challenge Sprint"
                                    activePracticeId = "daily-quiz"
                                    navController.navigate("practice")
                                }
                            )
                        }

                        composable("profile") {
                            UserProfileScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome,
                                onNavigateToSubscription = {
                                    navController.navigate("subscription")
                                },
                                onNavigateToLogin = {
                                    navController.navigate("login")
                                },
                                onNavigateToSavedQuestions = {
                                    navController.navigate("saved_questions")
                                },
                                onNavigateToPrivacy = {
                                    navController.navigate("privacy")
                                },
                                onNavigateToPerformance = {
                                    navController.navigate("performance")
                                },
                                onNavigateToNotificationSettings = {
                                    navController.navigate("notification_settings")
                                }
                            )
                        }

                        composable("notification_settings") {
                            NotificationSettingsScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome
                            )
                        }

                        composable("advanced_font_settings") {
                            AdvancedFontSettingsScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome
                            )
                        }

                        composable("leaderboard") {
                            com.example.ui.screens.LeaderboardScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome
                            )
                        }

                        composable("offline_manager") {
                            com.example.ui.screens.OfflineManagerScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome,
                                onNavigateToSubjectDetail = { sub ->
                                    selectedSubject = sub
                                    selectedUnit = sub.units.firstOrNull()
                                    selectedTopic = selectedUnit?.topics?.firstOrNull()
                                    navController.navigate("sets")
                                },
                                onStartOfflinePractice = { subjectId, unitId ->
                                    val sub = SampleData.subjectsState.find { it.id == subjectId } ?: SampleData.defaultSubjects.firstOrNull()
                                    if (sub != null) {
                                        selectedSubject = sub
                                        selectedUnit = sub.units.find { it.id == unitId }
                                        selectedTopic = selectedUnit?.topics?.firstOrNull()
                                        activePracticeQuestions = com.example.util.OfflineSyncManager.getQuestionsForPractice(this@MainActivity, subjectId, unitId, "")
                                        activePracticeTitle = "${sub.name} (Offline Practice)"
                                        activePracticeId = "offline-${subjectId}-${unitId}"
                                        navController.navigate("practice")
                                    }
                                },
                                onNavigateToBackupRestore = {
                                    navController.navigate("backup_restore")
                                }
                            )
                        }

                        composable("backup_restore") {
                            com.example.ui.screens.BackupRestoreScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome
                            )
                        }

                        composable("notifications") {
                            NotificationsScreen(
                                onBack = { navController.popBackStack() },
                                onNavigateToHome = navigateToHome,
                                onNavigateToDeepLink = { target ->
                                    val link = target.uppercase()
                                    when {
                                        link.contains("MOCK_TEST") -> navController.navigate("mock_tests")
                                        link.contains("CURRENT_AFFAIRS") -> navController.navigate("current_affairs")
                                        link.contains("SUBSCRIPTION") -> navController.navigate("subscription")
                                        link.contains("SYLLABUS") -> navController.navigate("syllabus")
                                        link.contains("DAILY_QUIZ") -> navController.navigate("daily_quiz")
                                        link.contains("PERFORMANCE") -> navController.navigate("performance")
                                        link.contains("LEADERBOARD") -> navController.navigate("leaderboard")
                                        link.contains("SPEED_DUEL") -> navController.navigate("speed_duel")
                                        else -> navController.navigate("home")
                                    }
                                 }
                            )
                        }

                        composable("previous_year_papers") {
                            PreviousYearPapersScreen(
                                onStartPaperAttempt = { paperTitle, questions, sessionId ->
                                    activePracticeTitle = paperTitle
                                    activePracticeQuestions = questions
                                    activePracticeId = sessionId
                                    activePracticeShowCelebration = true
                                    navController.navigate("practice")
                                },
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
    }
}
}

@Composable
private fun AppStartupLoadingScreen(appName: String) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.padding(24.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shadowElevation = 6.dp,
                    modifier = Modifier.size(80.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(42.dp)
                        )
                    }
                }

                Text(
                    text = appName.ifBlank { "Aspirant Portal" },
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                CircularProgressIndicator(
                    modifier = Modifier.size(32.dp),
                    color = MaterialTheme.colorScheme.primary,
                    strokeWidth = 3.dp
                )

                Text(
                    text = "Connecting secure services...",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}


